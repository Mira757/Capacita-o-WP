<?php
// Silence is golden.

<p>Teste</p>
